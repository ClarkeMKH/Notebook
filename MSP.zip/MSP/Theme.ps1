﻿# Theme.ps1 - UI styling and reusable components
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing


# --- Colour Palette ---
$Theme = @{
    Background  = [System.Drawing.Color]::FromArgb(45,  45,  55)   # Main window background
    Surface     = [System.Drawing.Color]::FromArgb(58,  58,  70)   # Header / nav background
    Panel       = [System.Drawing.Color]::FromArgb(50,  50,  62)   # Content area background
    Button      = [System.Drawing.Color]::FromArgb(68,  68,  82)   # Default button
    ButtonHover = [System.Drawing.Color]::FromArgb(85,  85, 100)   # Button hover
    ButtonDown  = [System.Drawing.Color]::FromArgb(52,  52,  64)   # Button pressed
    Border      = [System.Drawing.Color]::FromArgb(85,  85, 102)   # Borders and separators
    Accent      = [System.Drawing.Color]::FromArgb(99,  140, 255)  # Blue accent (header line)
    Text        = [System.Drawing.Color]::FromArgb(230, 230, 240)  # Primary text
    Font        = New-Object System.Drawing.Font("Segoe UI", 9)
    FontBold    = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
}


# --- Button ---
function New-Button {
    param(
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$W = 180,
        [int]$H = 45,
        [scriptblock]$OnClick
    )
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text      = $Text
    $btn.Location  = New-Object System.Drawing.Point($X, $Y)
    $btn.Size      = New-Object System.Drawing.Size($W, $H)
    $btn.BackColor = $script:Theme.Button
    $btn.ForeColor = $script:Theme.Text
    $btn.Font      = $script:Theme.FontBold
    $btn.FlatStyle = "Flat"
    $btn.FlatAppearance.BorderSize         = 1
    $btn.FlatAppearance.BorderColor        = $script:Theme.Border
    $btn.FlatAppearance.MouseOverBackColor = $script:Theme.ButtonHover
    $btn.FlatAppearance.MouseDownBackColor = $script:Theme.ButtonDown
    $btn.Cursor    = [System.Windows.Forms.Cursors]::Hand
    $btn.Add_Click($OnClick)
    return $btn
}


# --- Panel ---
function New-Panel {
    param(
        [int]$X,
        [int]$Y,
        [int]$W = 200,
        [int]$H = 100,
        [System.Drawing.Color]$Color = $script:Theme.Panel
    )
    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location  = New-Object System.Drawing.Point($X, $Y)
    $panel.Size      = New-Object System.Drawing.Size($W, $H)
    $panel.BackColor = $Color
    return $panel
}


# --- Label ---
function New-Label {
    param(
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$W = 0,
        [int]$H = 0,
        [int]$Size = 10,
        [bool]$Bold = $false
    )
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text      = $Text
    $lbl.Location  = New-Object System.Drawing.Point($X, $Y)
    $lbl.ForeColor = $script:Theme.Text
    $style = if ($Bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    $lbl.Font = New-Object System.Drawing.Font($script:Theme.Font.FontFamily, $Size, $style)
    if ($BoxWidth -gt 0) {
        $lbl.AutoSize  = $false
        $lbl.Size      = New-Object System.Drawing.Size($BoxWidth, $BoxHeight)
        $lbl.TextAlign = 'MiddleCenter'
    } else {
        $lbl.AutoSize = $true
    }
    return $lbl
}


# --- TextArea ---
function New-TextArea {
    param(
        [string]$Text = "",
        [int]$X,
        [int]$Y,
        [int]$W = 300,
        [int]$H = 150,
        [bool]$ReadOnly = $false,
        [string]$ScrollBars = "Vertical",   # None, Horizontal, Vertical, Both
        [bool]$WordWrap = $true
    )
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Multiline   = $true
    $txt.Text        = $Text
    $txt.Location    = New-Object System.Drawing.Point($X, $Y)
    $txt.Size        = New-Object System.Drawing.Size($W, $H)
    $txt.ScrollBars  = $ScrollBars
    $txt.WordWrap    = $WordWrap
    $txt.AcceptsReturn = $true
    $txt.AcceptsTab    = $true
    $txt.ReadOnly      = $ReadOnly

    $txt.BackColor   = $script:Theme.Panel
    $txt.ForeColor   = $script:Theme.Text
    $txt.Font        = $script:Theme.Font
    $txt.BorderStyle = "FixedSingle"

    return $txt
}