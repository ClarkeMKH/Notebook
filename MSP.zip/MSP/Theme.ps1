# Theme.ps1
# Contains all UI styling and reusable component functions

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing



# --- Colour Palette ---
$Theme = @{
    Background  = [System.Drawing.Color]::FromArgb(100, 100, 100)
    Button      = [System.Drawing.Color]::FromArgb(60, 60, 60)
    ButtonHover = [System.Drawing.Color]::FromArgb(80, 80, 80)
    ButtonDown  = [System.Drawing.Color]::FromArgb(40, 40, 40)
    Text        = [System.Drawing.Color]::White
    Font        = New-Object System.Drawing.Font("Segoe UI", 10)
}



# --- Reusable Button Function ---
function New-Button {
    param(
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$W = 180,
        [int]$H = 45,
        [scriptblock]$OnClick
    )
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Size = New-Object System.Drawing.Size($W, $H)
    $button.Location = New-Object System.Drawing.Point($X, $Y)
    $button.BackColor = $script:Theme.Button
    $button.ForeColor = $script:Theme.Text
    $button.FlatStyle = "Flat"
    $button.FlatAppearance.BorderSize = 0
    $button.FlatAppearance.MouseOverBackColor = $script:Theme.ButtonHover
    $button.FlatAppearance.MouseDownBackColor = $script:Theme.ButtonDown
    $button.Font = $script:Theme.Font
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    $button.Add_Click($OnClick)
    return $button
}



# --- Reusable Panel Function ---
function New-Panel {
    param(
        [int]$X,
        [int]$Y,
        [int]$W = 200,
        [int]$H = 100,
        [System.Drawing.Color]$Color = $script:Theme.Button
    )
    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location = New-Object System.Drawing.Point($X, $Y)
    $panel.Size = New-Object System.Drawing.Size($W, $H)
    $panel.BackColor = $Color
    return $panel
}