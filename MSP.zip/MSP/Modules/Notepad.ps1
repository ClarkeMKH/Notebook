﻿function Notepad {
    $script:ContentPanel.Controls.Clear()

    $textArea = New-TextArea -X 5 -Y 5 -W ($FullWidth - 10) -H ($FullHeight - 55)
    $textArea.Text = Load-Data -Key "Notes" -Default ""
    $textArea.Add_TextChanged({
        Save-Data -Key "Notes" -Value $textArea.Text
    }.GetNewClosure())
    $script:ContentPanel.Controls.Add($textArea)
}