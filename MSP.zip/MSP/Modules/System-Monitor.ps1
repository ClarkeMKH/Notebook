﻿function System-Monitor {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
