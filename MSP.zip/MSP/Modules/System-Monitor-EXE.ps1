﻿function System-Monitor-EXE {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
