﻿function Build-Companion-EXE {
    if (-not (Get-Module -ListAvailable -Name ps2exe)) {
        Install-Module -Name ps2exe -Scope CurrentUser -Force
    }

    $outputFile = "$PWD\Companion.exe"
    $counter = 1
    while (Test-Path $outputFile) {
        $outputFile = "$PWD\Companion ($counter).exe"
        $counter++
    }

    $moduleFiles = Get-ChildItem "$PWD\Modules\*.ps1" | Where-Object { $_.Name -ne "Create-Dev-Environment.ps1" }

    $rawTheme     = Get-Content "$PWD\Theme.ps1" -Raw
    $rawMain      = Get-Content "$PWD\Main.ps1" -Raw
    $encodedTheme = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($(if ($rawTheme) { $rawTheme } else { '' })))
    $encodedMain  = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($(if ($rawMain)  { $rawMain  } else { '' })))

    $moduleEntries = $moduleFiles | ForEach-Object {
        $raw     = Get-Content $_.FullName -Raw
        $safe    = if ($raw) { $raw } else { '' }
        $encoded = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($safe))
        "        '$($_.Name)' = '$encoded'"
    }
    $modulesBlock = $moduleEntries -join "`n"

    $devEnvScript = @"
function Create-Dev-Environment {
    `$themeContent = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$encodedTheme'))
    `$mainContent  = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$encodedMain'))
    `$moduleFiles  = @{
$modulesBlock
    }

    Set-Content -Path "`$PWD\Theme.ps1" -Value `$themeContent -Encoding UTF8
    Set-Content -Path "`$PWD\Main.ps1"  -Value `$mainContent  -Encoding UTF8

    New-Item -ItemType Directory -Path "`$PWD\Modules" -Force | Out-Null

    foreach (`$entry in `$moduleFiles.GetEnumerator()) {
        `$decoded = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(`$entry.Value))
        Set-Content -Path "`$PWD\Modules\`$(`$entry.Key)" -Value `$decoded -Encoding UTF8
    }

    [System.Windows.Forms.MessageBox]::Show("Dev environment ready at: `$PWD", "Operation Complete")
}
"@

    $devEnvPath = "$PWD\Modules\Create-Dev-Environment.ps1"
    Set-Content -Path $devEnvPath -Value $devEnvScript -Encoding UTF8

    $combined = @(
        Get-Content "$PWD\Theme.ps1"
        Get-ChildItem "$PWD\Modules\*.ps1" | ForEach-Object { Get-Content $_.FullName }
        Get-Content "$PWD\Main.ps1"
    ) -join "`n"

    $combined | Set-Content "$env:TEMP\build_temp.ps1"
    Invoke-ps2exe -inputFile "$env:TEMP\build_temp.ps1" -outputFile $outputFile -noConsole -iconFile "$PWD\logo.ico"
    Remove-Item "$env:TEMP\build_temp.ps1"

    [System.Windows.Forms.MessageBox]::Show("Build complete!`n$outputFile`n`nDev environment script updated:`n$devEnvPath", "Done")
}


