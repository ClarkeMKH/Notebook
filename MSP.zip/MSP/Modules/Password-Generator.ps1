﻿function Password-Generator {

    $offsetX = ($FullWidth / 2) - 300
    $offsetY = ($FullHeight / 2) - 200


    # ========== WORDS FOR PASSWORD GENERATION ==========
    $Words4 = @("blue","fast","calm","bold","warm","kind","true","open","free","glow","pure","wise","cool","fair","firm","gold","leaf","peak","rise","star","best","easy","epic","fine","grow","help","idea","jump","keep")
    $Words5 = @("happy","bring","light","quick","reach","dream","learn","teach","share","trust","smile","spark","shine","grasp","boost","guide","value","climb","voice","bloom","brave","clear","fresh","giant","ideal","laugh","merit")
    $Words6 = @("bright","gentle","honest","summer","winter","spring","autumn","wonder","friend","change","create","dazzle","expand","fluent","golden","harbor","invite","joyful","kindle","mentor","nature","option","polish","rhythm","serene","talent","unique","wisdom")
    $Specials = @("!","@","#","%","^","?")

    $w4 = Get-Random -InputObject $Words4
    $w5 = Get-Random -InputObject $Words5
    $w6 = Get-Random -InputObject $Words6
    $num = Get-Random -Minimum 0 -Maximum 10
    $special = Get-Random -InputObject $Specials

    $words = @($w4, $w5, $w6)
    $capIndex = Get-Random -Minimum 0 -Maximum 3
    $words[$capIndex] = $words[$capIndex].Substring(0,1).ToUpper() + $words[$capIndex].Substring(1)

    $parts = @($words[0], $words[1], $words[2], $num, $special)
    $shuffled = $parts | Get-Random -Count $parts.Count

    # ========== UNIQUELY GENERATED PASSWORD ==========
    $uniquePassword = -join $shuffled




    # ========== SHORT PWPUSH URL GENERATION VIA API V1 ==========
    $shortBody = @{
        "password[payload]" = $uniquePassword
        "password[expire_after_days]" = 3
        "password[expire_after_views]" = 5
    }
    $shortResponse = Invoke-RestMethod -Uri "https://eu.pwpush.com/p.json" -Method Post -Body $shortBody
    $shortPushUrl = "https://eu.pwpush.com/p/$($shortResponse.url_token)"




    # ========== LONG PWPUSH URL GENERATION VIA API V1 ==========
    $longBody = @{
        "password[payload]" = $uniquePassword
        "password[expire_after_days]" = 30
        "password[expire_after_views]" = 50
    }
    $longResponse = Invoke-RestMethod -Uri "https://eu.pwpush.com/p.json" -Method Post -Body $longBody
    $longPushUrl = "https://eu.pwpush.com/p/$($longResponse.url_token)"


    # ========== CLEARS PANEL READY FOR CONTENT ==========
    $panel = $script:ContentPanel
    $panel.Controls.Clear()

    # ========== PASSWORD BUTTONS ==========
    $displayPasswordText = New-Label -Text "Password :" -X (35 + $offsetX) -Y 10 -Size 20
    $displayPassword = New-Button -Text $uniquePassword -X 220 -Y 12 -W 200 -H 40 -OnClick ([scriptblock]::Create("Copy-Text-Clipboard -Text $uniquePassword"))
    $panel.Controls.Add($displayPasswordText)
    $panel.Controls.Add($displayPassword)

    # ========== SHORT PWPUSH BUTTONS ==========
    $shortURLText = New-Label -Text "Short PWPush :" -X (10 + $offsetX) -Y 80 -Size 20
    $shortURL = New-Button -Text "Click to Copy" -X 220 -Y 82 -W 200 -H 40 -OnClick ([scriptblock]::Create("Copy-Text-Clipboard -Text $shortPushUrl"))
    $panel.Controls.Add($shortURLText)
    $panel.Controls.Add($shortURL)

    # ========== LONG PWPUSH BUTTONS ==========
    $longURLText = New-Label -Text "Long PWPush :" -X 10 -Y 150 -Size 20
    $longURL = New-Button -Text "Click to Copy" -X 220 -Y 152 -W 200 -H 40 -OnClick ([scriptblock]::Create("Copy-Text-Clipboard -Text $longPushUrl"))
    $panel.Controls.Add($longURLText)
    $panel.Controls.Add($longURL)
}




function Copy-Text-Clipboard {
    param(
        [string]$Text
    )
    $Text | Set-Clipboard
    [System.Windows.Forms.MessageBox]::Show("$Text has been copied to your clipboard.", "Success")
}