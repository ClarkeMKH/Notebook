﻿function Password-Generator {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

