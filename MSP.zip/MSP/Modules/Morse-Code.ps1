﻿function Morse-Code {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

