﻿$global:ImagePlaygroundReady = $false
try {
    if (-not (Get-Module -ListAvailable -Name ImagePlayground)) {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope CurrentUser | Out-Null
        }
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
        Install-Module -Name ImagePlayground -Scope CurrentUser -Force -AllowClobber -Confirm:$false -ErrorAction Stop
    }
    Import-Module ImagePlayground -ErrorAction Stop
    $global:ImagePlaygroundReady = $true
} catch {
    $global:ImagePlaygroundError = $_.Exception.Message
}

function Asset-Label-Generator {
    $panel = $script:ContentPanel
    $panel.Controls.Clear()

    $panel.Controls.Add((New-Label -Text "Customer Name" -X 24 -Y 20))

    $txtCustomer = New-Object System.Windows.Forms.TextBox
    $txtCustomer.Location = New-Object System.Drawing.Point(24, 42)
    $txtCustomer.Size = New-Object System.Drawing.Size(300, 26)
    $panel.Controls.Add($txtCustomer)

    $panel.Controls.Add((New-Label -Text "Serial Number" -X 348 -Y 20))

    $txtSerial = New-Object System.Windows.Forms.TextBox
    $txtSerial.Location = New-Object System.Drawing.Point(348, 42)
    $txtSerial.Size = New-Object System.Drawing.Size(300, 26)
    $panel.Controls.Add($txtSerial)

    $exportClick = {
        try {
            if (-not $global:ImagePlaygroundReady) {
                [System.Windows.Forms.MessageBox]::Show(
                    "ImagePlayground module isn't available.`n`nOpen PowerShell and run:`nInstall-Module -Name ImagePlayground -Scope CurrentUser`n`nError: $global:ImagePlaygroundError",
                    "Missing module"
                )
                return
            }
            $customer = $txtCustomer.Text.Trim()
            $serial   = $txtSerial.Text.Trim()
            if ([string]::IsNullOrWhiteSpace($customer) -or [string]::IsNullOrWhiteSpace($serial)) {
                [System.Windows.Forms.MessageBox]::Show("Customer read as: '$customer'`nSerial read as: '$serial'`n`nEnter both a customer name and a serial number.", "Missing info")
                return
            }

            $barcodeFile = "$env:TEMP\barcode.png"
            $qrFile      = "$env:TEMP\qr.png"
            New-ImageBarCode -Type Code128 -Value $serial -FilePath $barcodeFile
            New-ImageQRCode -Content $serial -FilePath $qrFile

            $bmp = New-Object System.Drawing.Bitmap(700, 200)
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.Clear([System.Drawing.Color]::White)

            $fontBold = New-Object System.Drawing.Font("Segoe UI", 22, [System.Drawing.FontStyle]::Bold)
            $barcodeCenterX = 40 + (400 / 2)

            $custWidth = $g.MeasureString($customer, $fontBold).Width
            $g.DrawString($customer, $fontBold, [System.Drawing.Brushes]::Black, ($barcodeCenterX - $custWidth / 2), 0)

            $barcodeImg = [System.Drawing.Image]::FromFile($barcodeFile)
            $g.DrawImage($barcodeImg, 40, 40, 400, 100)
            $barcodeImg.Dispose()

            $serWidth = $g.MeasureString($serial, $fontBold).Width
            $g.DrawString($serial, $fontBold, [System.Drawing.Brushes]::Black, ($barcodeCenterX - $serWidth / 2), 122)

            $fontSmall = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
            $g.DrawString("www.crosstek.co.uk", $fontSmall, [System.Drawing.Brushes]::Black, 135, 160)

            $qrImg = [System.Drawing.Image]::FromFile($qrFile)
            $g.DrawImage($qrImg, 490, -10, 220, 220)
            $qrImg.Dispose()

            $g.Dispose()

            $sfd = New-Object System.Windows.Forms.SaveFileDialog
            $sfd.Filter = "PNG Image (*.png)|*.png"
            $sfd.FileName = "Label_$serial.png"
            if ($sfd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $bmp.Save($sfd.FileName, [System.Drawing.Imaging.ImageFormat]::Png)
            }
            $bmp.Dispose()
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Error: $($_.Exception.Message)", "Export failed")
        }
    }.GetNewClosure()
    $btnExport = New-Button -Text "Export Label" -X 24 -Y 90 -W 200 -H 40 -OnClick $exportClick
    $panel.Controls.Add($btnExport)
}