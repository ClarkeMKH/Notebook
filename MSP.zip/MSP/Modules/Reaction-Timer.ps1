﻿function Reaction-Timer {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

