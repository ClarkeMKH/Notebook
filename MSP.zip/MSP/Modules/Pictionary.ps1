﻿function Pictionary {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
