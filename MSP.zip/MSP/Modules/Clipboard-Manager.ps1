﻿function Clipboard-Manager {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
