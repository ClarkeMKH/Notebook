﻿function RSS-Viewer {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

