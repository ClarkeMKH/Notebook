﻿function Decision-Maker {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
