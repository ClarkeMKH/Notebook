﻿function AI-Chat {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
