function Custom-PowerShell {
    $script:ContentPanel.Controls.Clear()

    $textArea = New-TextArea -X 5 -Y 5 -W ($FullWidth - 10) -H ($FullHeight - 95)
    $textArea.Text = Load-Data -Key "Custom-PowerShell" -Default ""
    $textArea.Add_TextChanged({
        Save-Data -Key "Custom-PowerShell" -Value $textArea.Text
    }.GetNewClosure())
    $script:ContentPanel.Controls.Add($textArea)

    $runBtn = New-Button -Text "Run" -X 5 -Y ($FullHeight - 85) -W ($FullWidth - 10) -H 35 -OnClick { Invoke-Expression $textArea.Text }.GetNewClosure()

    $script:ContentPanel.Controls.Add($runBtn)
}
