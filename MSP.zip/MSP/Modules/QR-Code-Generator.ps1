﻿function QR-Code-Generator {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
