﻿function Connect-To-Tenancy {
    $GraphScopes = @(
        "Directory.ReadWrite.All"
        "User.ReadWrite.All"
        "Group.ReadWrite.All"
        "Application.ReadWrite.All"
        "RoleManagement.ReadWrite.Directory"
    )

    Connect-MgGraph -Scopes $GraphScopes

    [System.Windows.Forms.MessageBox]::Show("Connected as $((Get-MgContext).Account)", "Connected")
}