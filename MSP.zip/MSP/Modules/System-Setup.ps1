﻿function System-Setup {
    [System.Windows.Forms.MessageBox]::Show("System has been Setup", "Operation Complete")
}


