﻿function System-Setup {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

