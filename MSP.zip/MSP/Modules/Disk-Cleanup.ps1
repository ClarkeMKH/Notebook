﻿function Disk-Cleanup {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
