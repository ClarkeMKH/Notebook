﻿function Network-Scanner {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

