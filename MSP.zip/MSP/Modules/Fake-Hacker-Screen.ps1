﻿function Fake-Hacker-Screen {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

