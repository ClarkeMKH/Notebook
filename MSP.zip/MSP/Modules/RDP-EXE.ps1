﻿function RDP-EXE {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
