﻿function RDP-EXE {
    if (-not (Get-Module -ListAvailable -Name ps2exe)) {
        Install-Module -Name ps2exe -Scope CurrentUser -Force
    }

    $outputFile = "$PWD\RDP-Agent.exe"
    $counter = 1
    while (Test-Path $outputFile) {
        $outputFile = "$PWD\RDP-Agent ($counter).exe"
        $counter++
    }

    $script = @'
param([switch]$RunAsService)

$serviceName = "N8nPingService"
$installPath = "C:\ProgramData\N8nPing\Agent.exe"

if ($RunAsService) {
    # This is the service instance -- do the work
    while ($true) {
        try { Invoke-WebRequest -Uri "https://automation.harrison-home.co.uk/webhook-test/d8a4d3ae-8d71-4316-af21-70e6ffc9e427" -Method Head -UseBasicParsing -TimeoutSec 10 | Out-Null } catch {}
        Start-Sleep -Seconds 60
    }
} else {
    # First run -- install and exit
    New-Item -ItemType Directory -Path (Split-Path $installPath) -Force | Out-Null
    Copy-Item -Path ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName) -Destination $installPath -Force

    New-Service -Name $serviceName -BinaryPathName "`"$installPath`" -RunAsService" -StartupType Automatic
    Start-Service -Name $serviceName
}
'@

    $script | Set-Content "$env:TEMP\build_temp.ps1"
    Invoke-ps2exe -inputFile "$env:TEMP\build_temp.ps1" -outputFile $outputFile -noConsole -iconFile "$PWD\logo.ico"
    Remove-Item "$env:TEMP\build_temp.ps1"

    [System.Windows.Forms.MessageBox]::Show("Build complete!`n$outputFile", "Done")
}