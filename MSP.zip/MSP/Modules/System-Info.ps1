﻿function System-Info {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
