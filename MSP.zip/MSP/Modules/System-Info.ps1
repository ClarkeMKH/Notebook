﻿function System-Info {
    $outputText = ""

    # ========== CLEARS PANEL READY FOR CONTENT ==========
    $panel = $script:ContentPanel
    $panel.Controls.Clear()

    # ========== PASSWORD BUTTONS ==========
    #$panel.Controls.Add(New-Label -Text "Gathering System Info" -X (($fullWidth/2)-180) -Y (($fullHeight/2)-75) -Size 26)
    $panel.Refresh()

    $comp = Get-ComputerInfo

    $panel.Controls.Clear()
    
    $caption = $comp.CsCaption



    [System.Windows.Forms.MessageBox]::Show($outputText, "Response")
}

