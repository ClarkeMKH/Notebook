function Build-EXE {
    if (-not (Get-Module -ListAvailable -Name ps2exe)) {
        Install-Module -Name ps2exe -Scope CurrentUser -Force
    }

    # --- Find a filename that isn't in use ---
    $outputFile = "$PWD\MyMSPTool.exe"
    $counter = 1
    while (Test-Path $outputFile) {
        $outputFile = "$PWD\MyMSPTool ($counter).exe"
        $counter++
    }

    $combined = @(
        Get-Content "$PWD\Theme.ps1"
        Get-Content "$PWD\Modules\Build.ps1"
        Get-Content "$PWD\Main.ps1"
    ) -join "`n"

    $combined | Set-Content "$env:TEMP\build_temp.ps1"

    Invoke-ps2exe -inputFile "$env:TEMP\build_temp.ps1" -outputFile $outputFile -noConsole -iconFile "$PWD\logo.ico"

    Remove-Item "$env:TEMP\build_temp.ps1"

    [System.Windows.Forms.MessageBox]::Show("Build complete!`n$outputFile", "Done")
}