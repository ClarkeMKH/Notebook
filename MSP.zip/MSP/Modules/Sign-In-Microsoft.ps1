﻿function Sign-In-Microsoft {

    if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
        [System.Windows.Forms.MessageBox]::Show("Run this with Windows PowerShell 5.1, or 'pwsh -sta'.", "STA required") | Out-Null
        return
    }
    # Pin the module to a known-good version. To update, change this value deliberately
    # and test, rather than letting PSGallery's "latest" install silently.
    $script:MaxModuleVersion = "2.25.0"

    $installedModule = Get-Module -ListAvailable Microsoft.Graph.Authentication |
        Where-Object { $_.Version -le [version]$script:MaxModuleVersion } |
        Sort-Object Version -Descending |
        Select-Object -First 1

    if (-not $installedModule) {
        Install-Module Microsoft.Graph.Authentication -RequiredVersion $script:MaxModuleVersion -Scope CurrentUser -AllowClobber
        $installedModule = Get-Module -ListAvailable Microsoft.Graph.Authentication |
            Where-Object { $_.Version -eq [version]$script:MaxModuleVersion }
    }

    Import-Module Microsoft.Graph.Authentication -RequiredVersion $installedModule.Version

    $ClientId = "14d82eec-204b-4c2f-b7e8-296a70dab67e"
    $script:TenantId = "organizations"
    $Scopes = "Directory.Read.All User.Read.All Group.Read.All Application.Read.All RoleManagement.Read.Directory offline_access"

    try {
        $script:deviceCodeRequest = Invoke-RestMethod -Method Post `
            -Uri "https://login.microsoftonline.com/$($script:TenantId)/oauth2/v2.0/devicecode" `
            -Body @{ client_id = $ClientId; scope = $Scopes } -ErrorAction Stop
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Couldn't start sign-in: $($_.Exception.Message)", "Sign-in error") | Out-Null
        return
    }

    function script:Copy-ToClipboard($text) {
        try { [System.Windows.Forms.Clipboard]::SetText($text) }
        catch { [System.Windows.Forms.MessageBox]::Show("Couldn't copy: $($_.Exception.Message)") | Out-Null }
    }

    $script:ContentPanel.Controls.Clear()
    $script:btnUrl  = New-Button -Text "Copy URL"  -X 20 -Y 20 -OnClick { Copy-ToClipboard $script:deviceCodeRequest.verification_uri }
    $script:btnCode = New-Button -Text "Copy Code" -X 20 -Y 75 -OnClick { Copy-ToClipboard $script:deviceCodeRequest.user_code }
    $script:ContentPanel.Controls.Add($script:btnUrl)
    $script:ContentPanel.Controls.Add($script:btnCode)

    $script:tokenBody = @{
        grant_type  = "urn:ietf:params:oauth:grant-type:device_code"
        client_id   = $ClientId
        device_code = $script:deviceCodeRequest.device_code
    }
    $script:expiresAt = (Get-Date).AddSeconds($script:deviceCodeRequest.expires_in)

    $script:signInTimer = New-Object System.Windows.Forms.Timer
    $script:signInTimer.Interval = [Math]::Max($script:deviceCodeRequest.interval, 5) * 1000
    $script:signInTimer.Add_Tick({
        if ((Get-Date) -gt $script:expiresAt) {
            $script:signInTimer.Stop()
            [System.Windows.Forms.MessageBox]::Show("Device code expired. Click sign-in again.", "Expired") | Out-Null
            return
        }

        try {
            $tokenResponse = Invoke-RestMethod -Method Post `
                -Uri "https://login.microsoftonline.com/$($script:TenantId)/oauth2/v2.0/token" `
                -Body $script:tokenBody -ErrorAction Stop
        } catch {
            $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($err.error -eq 'authorization_pending') { return }
            if ($err.error -eq 'slow_down') { $script:signInTimer.Interval += 5000; return }
            $script:signInTimer.Stop()
            $msg = if ($err.error_description) { $err.error_description } else { $_.Exception.Message }
            [System.Windows.Forms.MessageBox]::Show("Sign-in failed: $msg", "Sign-in error") | Out-Null
            return
        }

        $script:signInTimer.Stop()

        $old = $Modules["Microsoft"]
        $new = [ordered]@{}

        foreach ($key in $old.Keys) {
            if ($key -eq "Sign in") {
                $new["Sign out"] = { Sign-Out-Microsoft }
            } else {
                $new[$key] = $old[$key]
            }
        }

        $Modules["Microsoft"] = $new
        Show-Modules -ModuleName 'Microsoft'
        Connect-MgGraph -AccessToken ($tokenResponse.access_token | ConvertTo-SecureString -AsPlainText -Force)
        [System.Windows.Forms.MessageBox]::Show("Connected as $((Get-MgContext).Account)", "Connected") | Out-Null
    })
    $script:signInTimer.Start()
}