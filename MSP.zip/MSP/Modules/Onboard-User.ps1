﻿function Onboard-User {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
