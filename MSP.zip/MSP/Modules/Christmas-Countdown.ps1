﻿function Christmas-Countdown {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

