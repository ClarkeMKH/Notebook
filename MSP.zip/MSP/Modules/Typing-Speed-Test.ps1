﻿function Typing-Speed-Test {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
