﻿function Manage-RDP {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

