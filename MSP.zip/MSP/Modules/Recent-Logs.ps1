﻿function Recent-Logs {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}

