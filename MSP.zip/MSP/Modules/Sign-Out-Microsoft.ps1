function Sign-Out-Microsoft {
    try {
        Disconnect-MgGraph -ErrorAction Stop | Out-Null
        [System.Windows.Forms.MessageBox]::Show("Disconnected.", "Disconnected") | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Not signed in, or disconnect failed: $($_.Exception.Message)", "Disconnect") | Out-Null
    }
    $old = $Modules["Microsoft"]
    $new = [ordered]@{}

    foreach ($key in $old.Keys) {
        if ($key -eq "Sign out") {
            $new["Sign in"] = { Sign-In-Microsoft }
        } else {
            $new[$key] = $old[$key]
        }
    }

    $Modules["Microsoft"] = $new
    Show-Modules -ModuleName 'Microsoft'
}