﻿function Wordle {
    [System.Windows.Forms.MessageBox]::Show("Not yet implemented.", "Error")
}
