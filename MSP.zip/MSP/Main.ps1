﻿# Main.ps1 - Entry point, loads modules and launches the app

if ($PSScriptRoot -and (Test-Path "$PSScriptRoot\Theme.ps1")) {
    . "$PSScriptRoot\Theme.ps1"
    Get-ChildItem "$PSScriptRoot\Modules\*.ps1" | ForEach-Object { . $_.FullName }
}


# --- Window ---
$FullWidth  = 800
$FullHeight = 800
$form = New-Object System.Windows.Forms.Form
$form.Text            = "Companion Tool"
$form.ClientSize      = New-Object System.Drawing.Size($FullWidth, $FullHeight)
$form.BackColor       = $Theme.Background
$form.StartPosition   = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox     = $false


# --- Icon ---
$form.Add_Shown({
    if (Test-Path "$PSScriptRoot\logo.ico") {
        $form.Icon = New-Object System.Drawing.Icon("$PSScriptRoot\logo.ico")
    } else {
        $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon(
            [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        )
    }
})


# --- Modules and their tools ---
$Modules = [ordered]@{
    "Connect to 365" = [ordered]@{}
    "Crosstek"     = [ordered]@{}
    "Tools"        = [ordered]@{
        "System Setup" = { System-Setup }
        "Create Development Environment" = { Create-Dev-Environment }
    }
    "Fun"          = [ordered]@{}
    "System"       = [ordered]@{}
    "Applications" = [ordered]@{
        "Build Companion EXE" = { Build-Companion-EXE }
    }
}


function Show-Menu {
    $script:form.Controls.Clear()
    # Nav bar - one button per module across the top
    $navHeight = 42
    $navWidth  = [int]($FullWidth / $Modules.Count)
    $navBar    = New-Panel -X 0 -Y 0 -W $FullWidth -H $navHeight -Color $Theme.Surface
    $i = 0
    foreach ($moduleName in $Modules.Keys) {
        $btn = New-Button -Text $moduleName -X ($navWidth * $i) -Y 0 -W $navWidth -H $navHeight `
            -OnClick ([scriptblock]::Create("Show-Modules -ModuleName '$moduleName'"))
        $btn.BackColor = $Theme.Surface
        $btn.FlatAppearance.BorderSize = 0
        $btn.Font = $Theme.Font
        $navBar.Controls.Add($btn)
        $i++
    }
    $form.Controls.Add($navBar)

    # Accent line below nav
    $form.Controls.Add((New-Panel -X 0 -Y $navHeight -W $FullWidth -H 2 -Color $Theme.Accent))

    # Content area
    $contentY = $navHeight + 2
    $script:ContentPanel = New-Panel -X 0 -Y $contentY -W $FullWidth -H ($FullHeight - $contentY)
    $form.Controls.Add($script:ContentPanel)
}


function Show-Modules {
    param([string]$ModuleName)

    $script:ContentPanel.Controls.Clear()

    # Tool buttons arranged in a grid
    $btnW    = 160
    $btnH    = 80
    $gap     = 16
    $col     = 0
    $row     = 0
    $maxCols = [math]::Floor(($script:ContentPanel.Width - $gap) / ($btnW + $gap))
    if ($maxCols -lt 1) { $maxCols = 1 }

    foreach ($toolName in $Modules[$ModuleName].Keys) {
        $x = $gap + $col * ($btnW + $gap)
        $y = $gap + $row * ($btnH + $gap)
        $script:ContentPanel.Controls.Add(
            (New-Button -Text $toolName -X $x -Y $y -W $btnW -H $btnH -OnClick $Modules[$ModuleName][$toolName])
        )
        $col++
        if ($col -ge $maxCols) { $col = 0; $row++ }
    }
}


Show-Menu

# --- Launch ---
$form.ShowDialog() | Out-Null


