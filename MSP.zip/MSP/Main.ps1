﻿# Main.ps1 - Entry point, loads modules and launches the app

if ($PSScriptRoot -and (Test-Path "$PSScriptRoot\Theme.ps1")) {
    . "$PSScriptRoot\Theme.ps1"
    Get-ChildItem "$PSScriptRoot\Modules\*.ps1" | ForEach-Object { . $_.FullName }
}


# --- Data Storage (next to the script) ---
$script:DataFile = Join-Path $PSScriptRoot "Companion Data.json"

if (-not (Test-Path $script:DataFile)) {
    "{}" | Set-Content -Path $script:DataFile -Encoding UTF8
}

function Get-Data {
    Get-Content -Path $script:DataFile -Raw | ConvertFrom-Json
}

function Save-Data {
    param(
        [Parameter(Mandatory)][string]$Key,
        [Parameter(Mandatory)]$Value
    )
    $data = Get-Data
    $data | Add-Member -MemberType NoteProperty -Name $Key -Value $Value -Force
    $data | ConvertTo-Json -Depth 10 | Set-Content -Path $script:DataFile -Encoding UTF8
}

function Load-Data {
    param(
        [Parameter(Mandatory)][string]$Key,
        $Default = $null
    )
    $data = Get-Data
    if ($data.PSObject.Properties.Name -contains $Key) { return $data.$Key }
    return $Default
}


# --- Window ---
$FullWidth  = 800
$FullHeight = 800
$form = New-Object System.Windows.Forms.Form
$form.Text            = "Companion Tool"
$form.ClientSize      = New-Object System.Drawing.Size($FullWidth, $FullHeight)
$form.BackColor       = $Theme.Background
$form.StartPosition   = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox     = $false


# --- Icon ---
$form.Add_Shown({
    if (Test-Path "$PSScriptRoot\logo.ico") {
        $form.Icon = New-Object System.Drawing.Icon("$PSScriptRoot\logo.ico")
    } else {
        $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon(
            [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        )
    }
})


# --- Modules and their tools ---
$Modules = [ordered]@{
    "Connect to 365" = [ordered]@{
        "Connect to Tenancy" = { Connect-To-Tenancy }
        "Modify a User" = { Modify-User }
        "Modify a Group" = { Modify-Group }
        "Onboard a User" = { Onboard-User }
        "Offboard a User" = { Offboard-User }
        "Generate Security Report" = { Generate-Security-Report }
    }
    "Crosstek" = [ordered]@{
        "Asset Label Generator" = { Asset-Label-Generator }
    }
    "Tools" = [ordered]@{
        "Create Development Environment" = { [System.Windows.Forms.MessageBox]::Show("Wow, that was close!", "Warning") }
        "System Setup" = { System-Setup }
        "Password Generator" = { Password-Generator }
        "Notepad" = { Notepad }
        "RSS Viewer" = { RSS-Viewer }
        "QR Code Generator" = { QR-Code-Generator }
        "Network Scanner" = { Network-Scanner }
        "Port Scanner" = { Port-Scanner }
        "Clipboard Manager" = { Clipboard-Manager }
        "AI Chat" = { AI-Chat }
        "Manage RDP" = { Manage-RDP }
    }
    "Fun" = [ordered]@{
        "Decision Maker" = { Decision-Maker }
        "Fake Hacker Screen" = { Fake-Hacker-Screen }
        "Morse Code" = { Morse-Code }
        "Typing Speed Test" = { Typing-Speed-Test }
        "Reaction Timer" = { Reaction-Timer }
        "Pictionary" = { Pictionary }
        "Minesweeper" = { Minesweeper }
        "Wordle" = { Wordle }
        "Christmas-Countdown" = { Christmas-Countdown }
    }
    "System" = [ordered]@{
        "System Info" = { System-Info }
        "System Monitor" = { System-Monitor }
        "Disk Cleanup" = { Disk-Cleanup }
        "Recent Logs" = { Recent-Logs }
    }
    "Applications" = [ordered]@{
        "Build Companion EXE" = { Build-Companion-EXE }
        "System Setup EXE" = { System-Setup-EXE }
        "System Monitor EXE" = { System-Monitor-EXE }
        "RDP EXE" = { RDP-EXE }
    }
}


function Show-Menu {
    $script:form.Controls.Clear()
    $navHeight = 42
    $navWidth  = [int]($FullWidth / $Modules.Count)
    $navBar    = New-Panel -X 0 -Y 0 -W $FullWidth -H $navHeight -Color $Theme.Surface

    $script:NavButtons = @{}
    $i = 0
    foreach ($moduleName in $Modules.Keys) {
        $btn = New-Button -Text $moduleName -X ($navWidth * $i) -Y 0 -W $navWidth -H $navHeight `
            -OnClick ([scriptblock]::Create("Show-Modules -ModuleName '$moduleName'"))
        $btn.BackColor = $Theme.Surface
        $btn.FlatAppearance.BorderSize = 0
        $btn.Font = $Theme.Font
        $navBar.Controls.Add($btn)
        $script:NavButtons[$moduleName] = $btn
        $i++
    }
    $form.Controls.Add($navBar)

    $form.Controls.Add((New-Panel -X 0 -Y $navHeight -W $FullWidth -H 2 -Color $Theme.Accent))

    $contentY = $navHeight + 2
    $script:ContentPanel = New-Panel -X 0 -Y $contentY -W $FullWidth -H ($FullHeight - $contentY)
    $form.Controls.Add($script:ContentPanel)
}


function Show-Modules {
    param([string]$ModuleName)

    foreach ($name in $script:NavButtons.Keys) {
        $script:NavButtons[$name].BackColor = $Theme.Surface
    }
    $script:NavButtons[$ModuleName].BackColor = $Theme.Accent

    $script:ContentPanel.Controls.Clear()

    $cols = 4
    $rows = 4
    $gap  = 16

    $availW = $script:ContentPanel.Width  - ($gap * ($cols + 1))
    $availH = $script:ContentPanel.Height - ($gap * ($rows + 1))

    $btnW = [int]($availW / $cols)
    $btnH = [int]($availH / $rows)

    $col = 0
    $row = 0

    foreach ($toolName in $Modules[$ModuleName].Keys) {
        $x = $gap + $col * ($btnW + $gap)
        $y = $gap + $row * ($btnH + $gap)
        $script:ContentPanel.Controls.Add(
            (New-Button -Text $toolName -X $x -Y $y -W $btnW -H $btnH -OnClick $Modules[$ModuleName][$toolName])
        )
        $col++
        if ($col -ge $cols) { $col = 0; $row++ }
        if ($row -ge $rows) { break }
    }
}


Show-Menu

# --- Launch ---
$form.ShowDialog() | Out-Null