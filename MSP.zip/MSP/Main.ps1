# Entry point - loads modules and launches the app
if ($PSScriptRoot -and (Test-Path "$PSScriptRoot\Theme.ps1")) {
    . "$PSScriptRoot\Theme.ps1"
    . "$PSScriptRoot\Modules\Build.ps1"
}




# --- Window ---
$FullWidth = 800
$FullHeight = 800
$form = New-Object System.Windows.Forms.Form
$form.Text = "Companion Tool"
$form.ClientSize = New-Object System.Drawing.Size($FullWidth, $FullHeight)
$form.BackColor = $Theme.Background
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false



# --- Icon ---
$form.Add_Shown({
    if (Test-Path "$PSScriptRoot\logo.ico") {
        $form.Icon = New-Object System.Drawing.Icon("$PSScriptRoot\logo.ico")
    } else {
        $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon(
            [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        )
    }
})



$Modules = @{
    "Applications" = @{

    }
    "System" = @{

    }
    "Fun" = @{

    }
    "Tools" = @{

    }
    "Crosstek" = @{

    }
    "Connect to 365" = @{
        "Reset Password" = { Write-Host "Resetting password..." }
    }
}




function Show-Menu {

    $NumberOfModules = $Modules.Count

    # --- Add Menu Buttons ---
    for ($i = 0; $i -lt $NumberOfModules; $i++) {
        $form.Controls.Add((New-Button -Text @($Modules.Keys)[$i] -X (5+((($FullWidth-10)/$NumberOfModules)*$i)) -Y 5 -W (($FullWidth-10)/$NumberOfModules) -H 30 -OnClick {
            [System.Windows.Forms.MessageBox]::Show("It works!", "Title")
        }))
    }

    $form.Controls.Add(( New-Panel -X 5 -Y 40 -W ($FullWidth-10) -H ($FullHeight-45) ))
}



function Show-Modules {
    param(
        [string]$ModuleName
    )

    
}



Show-Menu



# --- Launch ---
$form.ShowDialog()